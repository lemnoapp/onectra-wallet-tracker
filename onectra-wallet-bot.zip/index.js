// ONECTRA Wallet Bot - Replit Entry Point
// This file serves as the main entry point for Replit hosting

console.log('🚀 Starting ONECTRA Wallet Bot on Replit...');

// Start the main application with Express server
require('./main.js');
